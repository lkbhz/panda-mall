<template>
  <div class="home">
    <div class="hearder">
      <div class="logo">
        <img class="img"
             src="../assets/images/logo.png"
             alt="logo">
        <div class="right">
          <h3>熊猫优选</h3>
          <span>XIONG MAO YOU XUAN</span>
        </div>
      </div>
      <div class="input">
        <div class="seach">
          <a-input placeholder="搜索更多商品，发现更多优惠"
                   style="width: 330px; margin-left: 50px; border: none" />
          <a-button type="primary"
                    style=" width: 120px; margin-left: 10px; color: #43200c; background: #fee44e; border: 1px solid #fee44e"
                    shape="round">搜索</a-button>
        </div>
      </div>
      <div class="advantage">
        <div class="item">
          <img src="../assets/images/baoyou.png"
               alt="包邮">
          <span>全程包邮</span>
        </div>
        <div class="item">
          <img src="../assets/images/tuihuan.png"
               alt="tuihuan">
          <span>7天退还</span>
        </div>
        <div class="item">
          <img src="../assets/images/baoz.png"
               alt="baoz">
          <span>品质保证</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  // @ is an alias to /src

  export default {
    name: 'Home',
  }
</script>

<style lang="scss" scoped>
  .home {
    width: 100%;
    height: 200px;
    display: flex;
    justify-content: space-evenly;
    .hearder {
      width: 1200px;
      height: 100%;
      display: flex;
      padding: 0 20px;
      .logo {
        width: 225px;
        height: 75px;
        margin-top: 50px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .img {
          width: 75px;
          height: 75px;
        }
        .right {
          text-align: center;
          h3 {
            font-size: 28px;
            font-weight: 600;
            line-height: 40px;
            color: #43200c;
            margin: 0;
          }
          span {
            display: inline-block;
            font-size: 12px;
            line-height: 17px;
            transform: scale(0.8);
          }
        }
      }
      .input {
        height: 48px;
        margin-top: 50px;
        flex: 1;
        display: flex;
        justify-content: center;
        .seach {
          width: 532px;
          height: 48px;
          border-radius: 34px;
          box-shadow: inset 0 0 0 2px #43240c;
          background: url('../assets/images/search.png') no-repeat center left 15px/20px 20px;
          display: flex;
          align-items: center;
        }
      }
      .advantage {
        width: 182px;
        height: 60px;
        margin-top: 50px;
        display: flex;
        justify-content: space-between;
        .item {
          width: 48px;
          height: 100%;
          font-size: 12px;
          color: #877a73;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          img {
            width: 40px;
            height: 40px;
          }
        }
      }
    }
  }
</style>
